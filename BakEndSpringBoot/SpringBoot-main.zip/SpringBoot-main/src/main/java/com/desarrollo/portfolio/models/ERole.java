
package com.desarrollo.portfolio.models;


public enum ERole {
  USUARIO,
  COLABORADOR,
  ADMINISTRADOR
}